To build:

`python -m build`

To deploy:

`twine upload dist/*`

